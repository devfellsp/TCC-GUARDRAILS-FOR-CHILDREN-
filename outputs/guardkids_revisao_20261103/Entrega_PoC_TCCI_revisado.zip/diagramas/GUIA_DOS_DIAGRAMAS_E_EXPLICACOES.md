# Diagramas do GuardKids — revisão de 03/11/2026

Os sete diagramas possuem fontes Draw.io e versões SVG. O arquivo `Todos_os_Diagramas_TCC_GuardKids.drawio` reúne as sete abas. Regenere todos com `python diagramas/gerar_diagramas.py`.

Os desenhos distinguem arquitetura conceitual, implementação GK-P1.2 e resultados históricos. O TCC usa três figuras próprias em `texto/figura_*.tex`; os sete desenhos externos são materiais complementares. As ações observadas não são métricas de adequação. Dois lotes novos de desenvolvimento estão em `avaliacao/evidencias/`; a avaliação final e os julgamentos humanos estão pendentes.

## 1. Dilema de calibração

Arquivos `drawio/01_dilema_calibracao_guardrails.drawio` e `svg/01_dilema_calibracao_guardrails.svg`. Mostra o problema conceitual entre permissividade, restrição excessiva e decisão contextual. As taxas indicadas são variáveis do protocolo, não resultados medidos da versão atual.

## 2. Referência classificatória e contexto

Arquivos `drawio/02_fluxo_classificacao_indicativa.drawio` e `svg/02_fluxo_classificacao_indicativa.svg`. Sintetiza a adaptação metodológica de descritores e contextos ao cenário do estudo. Não atribui classificação oficial ao chatbot nem torna a exceção educativa superior ao sinal de proteção. O perfil de nove anos não representa toda a faixa de sete a onze anos.

## 3. Arquitetura conceitual

Arquivos `drawio/03_arquitetura_conceitual_integrada.drawio` e `svg/03_arquitetura_conceitual_integrada.svg`. Apresenta perfil fixo, políticas, recuperação e controle de parâmetros. A versão atual omite texto livre dos registros comuns. A detecção local de alguns identificadores explícitos é parcial; não garante ausência de dados pessoais. Temperatura e semente fixas reduzem variação, mas não garantem determinismo.

## 4. Comparação experimental

Arquivos `drawio/04_protocolo_experimental_metodologia.drawio` e `svg/04_protocolo_experimental_metodologia.svg`. Plano prospectivo com 40 perguntas/20 famílias, grupos G1–G5, duas condições e duas repetições (160 oportunidades). Origem, exposição, ordem e perdas em `avaliacao/PROTOCOLO.md`; referências humanas pendentes. A referência é uma ablação conservadora. Não se demonstra a melhor alternativa disponível ou independência externa dos casos.

## 5. Fluxo implementado

Arquivos `drawio/05_pipeline_5_etapas_guardkids.drawio` e `svg/05_pipeline_5_etapas_guardkids.svg`. A implementação está em `poc/guardkids.py`, a API em `poc/app.py`, e o executor em `poc/run_development.py`. A rota de perguntas é `POST /api/ask`.

Os cinco blocos agrupam: proteção de entrada; recuperação com índice validado; geração estruturada; validação de IDs, limite de palavras e verificação adicional de sustentação; e proteção de saída. Falta de apoio retorna `redirect`; citação inválida ou falha de esquema retorna `technical_error`. O classificador de sustentação também usa Qwen3 e pode errar. Proteção retorna `block` ou `safe_guidance`, conforme a categoria. O texto rejeitado não é enviado à interface. Logs em `poc/runs/<id>.json` são minimizados, e `generated.answer` integral só é persistido no modo explicitamente fictício. Falha de gravação retém a resposta.

## 6. Curadoria e indexação

Arquivos `drawio/06_curadoria_e_indexacao_rag.drawio` e `svg/06_curadoria_e_indexacao_rag.svg`. O manifesto usa `start`, `end` opcional e exclusões justificadas. Cinco passagens são selecionadas das duas apostilas. A divisão atual aplica limite rígido de 850 caracteres, reduzindo a sobreposição se necessário. Vetores e metadados são publicados em `poc/data/indices/<id>/`, e `poc/data/current.json` passa a apontar para a versão completa. A leitura valida texto, páginas, PDFs, hashes, dimensões e normalização. A conferência textual normaliza espaços. A disponibilidade pública das obras não dispensa revisão dos direitos e créditos de terceiros.

## 7. Precedência das políticas

Arquivos `drawio/07_arvore_decisao_referencia_vs_ajustada.drawio` e `svg/07_arvore_decisao_referencia_vs_ajustada.svg`. Representa `decision`: proteção precede a exceção educativa. Autolesão/privacidade recebem `safe_guidance`; ajuda reconhecida em danger/sexual/hate/substance também recebe orientação; demais riscos são bloqueados. Injeção não recebe exceção de ajuda. Sem proteção e sem predação, retorna `allow`. O reconhecimento contextual pode falhar, como mostram os lotes novos.

No piloto histórico, dev03 foi bloqueado na referência e permitido na ajustada. As rotas protetivas foram exercitadas em dev05 a dev11. Isso não autoriza declarar eficácia de 100% nem calcular taxas de conteúdo sem revisão humana. Os valores históricos, as respostas literais e os identificadores completos estão na evidência versionada.
