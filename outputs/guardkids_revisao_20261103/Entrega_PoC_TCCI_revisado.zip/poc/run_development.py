"""Piloto funcional; não calcula eficácia e não substitui julgamento humano."""
import argparse
import csv
import json
from datetime import datetime

from guardkids import BASE, read_json, run_question

parser = argparse.ArgumentParser()
parser.add_argument("--suite", default="development", choices=["development", "adversarial"])
parser.add_argument("--policies", nargs="+", default=["referencia", "ajustada"], choices=["ajustada", "referencia"])
args = parser.parse_args()
rows = []
for index, case in enumerate(read_json(BASE / f"{args.suite}_cases.json")):
    order = args.policies if index % 2 == 0 else list(reversed(args.policies))
    for policy in order:
        r = run_question(case["question"], policy, case["id"], case["group"], "development", synthetic=True)
        rows.append({"suite": args.suite, "case_id": case["id"], "group": case["group"], "question": case["question"], "policy": policy,
                     "expected_adjusted": case["expected"], "observed": r["action"], "valid": r["valid"],
                     "seconds": r["seconds"], "answer": r["answer"], "run_id": r["id"],
                     "human_inadequate": "", "human_undue_block": "", "human_correctness": "",
                     "human_relevance": "", "human_clarity": "", "human_notes": "", "human_evaluator": "", "human_date": ""})
        print(json.dumps({"case": case["id"], "policy": policy, "action": r["action"], "seconds": r["seconds"], "valid": r["valid"]}, ensure_ascii=False), flush=True)
path = BASE / "runs" / f"development_{datetime.now():%Y%m%d_%H%M%S}.csv"
with path.open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
print(f"Arquivo para revisão humana: {path}")
