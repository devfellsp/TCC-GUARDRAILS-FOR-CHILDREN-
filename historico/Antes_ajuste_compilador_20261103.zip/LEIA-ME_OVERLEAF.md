# GuardKids — Projeto/TCC I revisado

1. Importe `Overleaf_TCC_GuardKids.zip` como novo projeto no Overleaf.
2. Selecione `main.tex` como documento principal e **XeLaTeX** como compilador. TeX Live 2025 ou posterior é recomendado; não foi executada compilação no serviço Overleaf nesta revisão.
3. Compile novamente se necessário para atualizar sumário, listas e referências. A entrada `document.tex` apenas carrega `main.tex`.
4. Edite os capítulos em `texto/`. As tabelas `generated/development_*.tex` são geradas das evidências locais, não contêm julgamentos humanos. Não as trate como resultados finais.

O pacote é autossuficiente para compilar o texto; não precisa dos modelos nem PDFs didáticos. Utiliza abnTeX2, fontspec, TikZ e algorithm2e. No Windows usa Times New Roman instalada; em ambiente sem essa fonte usa TeX Gyre Termes, compatível visualmente mas não idêntica. Conferir exigência de fonte com orientador antes da entrega institucional. Não redistribuir arquivos de fonte proprietária sem licença.

A versão foi verificada localmente com Tectonic 0.17.0/XeTeX. A compilação foi concluída e o PDF foi inspecionado visualmente. A ratificação de referências, a revisão humana de conteúdo e a avaliação final estão pendentes. A ausência de banca/assinaturas nesta versão é intencional: não se declara aprovação de um Projeto/TCC I ainda em elaboração.
